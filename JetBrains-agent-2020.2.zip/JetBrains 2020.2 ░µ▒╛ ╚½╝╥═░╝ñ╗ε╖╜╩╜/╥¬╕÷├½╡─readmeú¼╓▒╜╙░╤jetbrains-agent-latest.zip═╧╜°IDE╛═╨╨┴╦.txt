要个毛的readme，直接把jetbrains-agent-latest.zip拖进IDE就行了
https://zhile.io/2018/08/18/jetbrains-license-server-crack.html